# convert grayscale to RGB
# convert RGB to grayscale
